import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"

const words = [
  'crow', 'sparrow', 'eagle', 'robin', 'pigeon',
  'cat', 'dog', 'tree', 'car', 'house',
  'book', 'phone', 'computer', 'chair', 'table',
  'pencil', 'window', 'door', 'shoe', 'hat'
];
const birdNames = ['crow', 'sparrow', 'eagle', 'robin', 'pigeon'];

export function BirdGame() {
  const [currentWord, setCurrentWord] = useState('');
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [isGameStarted, setIsGameStarted] = useState(false);

  const generateWord = useCallback(() => {
    const newWord = words[Math.floor(Math.random() * words.length)];
    setCurrentWord(newWord);
  }, []);

  useEffect(() => {
    if (isGameStarted && !gameOver) {
      const wordInterval = setInterval(() => {
        generateWord();
      }, 2000);

      return () => clearInterval(wordInterval);
    }
  }, [isGameStarted, gameOver, generateWord]);

  const handleButtonClick = () => {
    if (gameOver) return;

    if (birdNames.includes(currentWord)) {
      setScore((prevScore) => prevScore + 1);
    } else {
      setGameOver(true);
    }
  };

  const resetGame = () => {
    setScore(0);
    setGameOver(false);
    setIsGameStarted(false);
    setCurrentWord('');
  };

  const startGame = () => {
    setIsGameStarted(true);
    generateWord();
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-gray-100 p-4">
      <AnimatePresence>
        {!isGameStarted && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="flex justify-center items-center absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          >
            <Button 
              onClick={startGame} 
              className="w-56 h-20 text-xl bg-gray-800 text-gray-100 hover:bg-gray-700 rounded-lg shadow-lg"
            >
              Start Game
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isGameStarted && (
          <motion.div
            className="text-center -mt-20"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-5xl font-bold mb-6 text-gray-100">{currentWord}</h2>
            <p className="text-xl mb-6 text-gray-300">Score: {score}</p>
            {gameOver && (
              <div>
                <p className="text-2xl text-red-400 mt-4 mb-4">Game Over!</p>
                <Button onClick={resetGame} className="text-lg py-2 px-4 bg-gray-800 text-gray-100 hover:bg-gray-700 rounded-md shadow-md">
                  Play Again
                </Button>
              </div>
            )}
            {!gameOver && (
              <Button 
                onClick={handleButtonClick} 
                className="w-56 h-20 text-xl bg-gray-800 text-gray-100 hover:bg-gray-700 rounded-lg shadow-lg"
              >
                Bird
              </Button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

