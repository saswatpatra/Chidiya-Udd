import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button"

// List of words including bird names and other words
const words = ['crow', 'sparrow', 'eagle', 'cat', 'dog', 'tree', 'robin', 'car', 'house', 'pigeon'];
const birdNames = ['crow', 'sparrow', 'eagle', 'robin', 'pigeon'];

export function BirdGame() {
  const [currentWord, setCurrentWord] = useState('');
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [timeLeft, setTimeLeft] = useState(2);
  const [isCrowActive, setIsCrowActive] = useState(false);

  const generateWord = useCallback(() => {
    const newWord = words[Math.floor(Math.random() * words.length)];
    setCurrentWord(newWord);
    if (newWord === 'crow') {
      setIsCrowActive(true);
      setTimeLeft(2);
    } else {
      setIsCrowActive(false);
    }
  }, []);

  useEffect(() => {
    if (!gameOver) {
      const wordInterval = setInterval(generateWord, 2000);
      return () => clearInterval(wordInterval);
    }
  }, [gameOver, generateWord]);

  useEffect(() => {
    if (isCrowActive && !gameOver) {
      const timer = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime <= 0) {
            clearInterval(timer);
            setGameOver(true);
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isCrowActive, gameOver]);

  const handleButtonClick = () => {
    if (gameOver) return;

    if (birdNames.includes(currentWord)) {
      setScore((prevScore) => prevScore + 1);
      generateWord();
    } else {
      setGameOver(true);
    }
  };

  const resetGame = () => {
    setScore(0);
    setGameOver(false);
    setTimeLeft(2);
    setIsCrowActive(false);
    generateWord();
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100 p-4">
      <div className="text-center mb-8">
        <h2 className="text-6xl font-bold mb-6">{currentWord}</h2>
        <p className="text-2xl mb-2">Score: {score}</p>
        {isCrowActive && <p className="text-2xl text-red-500">Time left: {timeLeft}s</p>}
        {gameOver && (
          <div>
            <p className="text-3xl text-red-500 mt-4">Game Over!</p>
            <Button onClick={resetGame} className="mt-4 text-xl py-2 px-4">
              Play Again
            </Button>
          </div>
        )}
      </div>

      <Button onClick={handleButtonClick} className="w-64 h-24 text-2xl">
        Click for Bird
      </Button>
    </div>
  );
}

