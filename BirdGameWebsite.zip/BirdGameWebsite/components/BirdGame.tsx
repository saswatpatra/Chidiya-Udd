import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"

const words = ['crow', 'sparrow', 'eagle', 'cat', 'dog', 'tree', 'robin', 'car', 'house', 'pigeon'];
const birdNames = ['crow', 'sparrow', 'eagle', 'robin', 'pigeon'];

export function BirdGame() {
  const [currentWord, setCurrentWord] = useState('');
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [timeLeft, setTimeLeft] = useState(2);
  const [isCrowActive, setIsCrowActive] = useState(false);
  const [isGameStarted, setIsGameStarted] = useState(false);

  const generateWord = useCallback(() => {
    const newWord = words[Math.floor(Math.random() * words.length)];
    setCurrentWord(newWord);
    if (newWord === 'crow') {
      setIsCrowActive(true);
      setTimeLeft(2);
    } else {
      setIsCrowActive(false);
    }
  }, []);

  useEffect(() => {
    if (isGameStarted && !gameOver) {
      const wordInterval = setInterval(generateWord, 2000);
      return () => clearInterval(wordInterval);
    }
  }, [isGameStarted, gameOver, generateWord]);

  useEffect(() => {
    if (isCrowActive && !gameOver) {
      const timer = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime <= 0) {
            clearInterval(timer);
            setGameOver(true);
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isCrowActive, gameOver]);

  const handleButtonClick = () => {
    if (gameOver) return;

    if (birdNames.includes(currentWord)) {
      setScore((prevScore) => prevScore + 1);
      generateWord();
    } else {
      setGameOver(true);
    }
  };

  const resetGame = () => {
    setScore(0);
    setGameOver(false);
    setTimeLeft(2);
    setIsCrowActive(false);
    setIsGameStarted(false);
    setCurrentWord('');
  };

  const startGame = () => {
    setIsGameStarted(true);
    generateWord();
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-gray-100 p-4">
      <style jsx global>{`
        @keyframes neon-border {
          0% {
            background-position: 0% 50%;
          }
          100% {
            background-position: 100% 50%;
          }
        }
        .neon-button {
          position: relative;
          overflow: hidden;
        }
        .neon-button::before {
          content: '';
          position: absolute;
          top: -2px;
          left: -2px;
          right: -2px;
          bottom: -2px;
          background: linear-gradient(90deg, #ff00ff, #00ffff, #ff00ff);
          background-size: 200% 200%;
          z-index: -1;
          opacity: 0;
          transition: opacity 0.3s ease;
        }
        .neon-button:hover::before {
          opacity: 1;
          animation: neon-border 1.5s linear infinite;
        }
      `}</style>
      <AnimatePresence>
        {!isGameStarted && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="flex justify-center items-center"
          >
            <Button 
              onClick={startGame} 
              className="w-56 h-20 text-xl bg-gray-800 text-gray-100 hover:bg-gray-700 hover:scale-105 transition-all duration-300 ease-in-out neon-button rounded-lg shadow-lg"
            >
              Start Game
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isGameStarted && (
          <motion.div
            className="text-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-5xl font-bold mb-6 text-gray-100">{currentWord}</h2>
            <p className="text-xl mb-2 text-gray-300">Score: {score}</p>
            {isCrowActive && <p className="text-xl text-red-400">Time left: {timeLeft}s</p>}
            {gameOver && (
              <div>
                <p className="text-2xl text-red-400 mt-4">Game Over!</p>
                <Button onClick={resetGame} className="mt-4 text-lg py-2 px-4 bg-gray-800 text-gray-100 hover:bg-gray-700 neon-button rounded-md shadow-md">
                  Play Again
                </Button>
              </div>
            )}
            {!gameOver && (
              <Button 
                onClick={handleButtonClick} 
                className="w-56 h-20 text-xl mt-8 bg-gray-800 text-gray-100 hover:bg-gray-700 hover:scale-105 transition-all duration-300 ease-in-out neon-button rounded-lg shadow-lg"
              >
                Bird
              </Button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

