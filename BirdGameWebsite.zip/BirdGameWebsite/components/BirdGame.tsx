import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"

const words = [
  'crow', 'sparrow', 'eagle', 'robin', 'pigeon',
  'cat', 'dog', 'tree', 'car', 'house',
  'book', 'phone', 'computer', 'chair', 'table',
  'pencil', 'window', 'door', 'shoe', 'hat'
];
const birdNames = ['crow', 'sparrow', 'eagle', 'robin', 'pigeon'];

export function BirdGame() {
  const [currentWord, setCurrentWord] = useState('');
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [isGameStarted, setIsGameStarted] = useState(false);
  const [countdown, setCountdown] = useState(3);

  const generateWord = useCallback(() => {
    const newWord = words[Math.floor(Math.random() * words.length)];
    setCurrentWord(newWord);
  }, []);

  useEffect(() => {
    if (isGameStarted && !gameOver && countdown === 0) {
      const wordInterval = setInterval(() => {
        if (birdNames.includes(currentWord)) {
          setGameOver(true);
        } else {
          generateWord();
        }
      }, 2000);

      return () => clearInterval(wordInterval);
    }
  }, [isGameStarted, gameOver, generateWord, currentWord, countdown]);

  useEffect(() => {
    if (isGameStarted && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);

      return () => clearTimeout(timer);
    }

    if (countdown === 0 && !gameOver) {
      generateWord();
    }
  }, [isGameStarted, countdown, gameOver, generateWord]);

  useEffect(() => {
    if (gameOver && score > highScore) {
      setHighScore(score);
    }
  }, [gameOver, score, highScore]);

  const handleButtonClick = () => {
    if (gameOver) return;

    if (birdNames.includes(currentWord)) {
      setScore((prevScore) => prevScore + 1);
      generateWord();
    } else {
      setGameOver(true);
    }
  };

  const resetGame = () => {
    setScore(0);
    setGameOver(false);
    setIsGameStarted(false);
    setCurrentWord('');
    setCountdown(3);
  };

  const startGame = () => {
    setIsGameStarted(true);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-gray-100 p-4">
      <style jsx global>{`
        @keyframes neon-border {
          0% {
            background-position: 0% 50%;
          }
          100% {
            background-position: 100% 50%;
          }
        }
        .neon-button {
          position: relative;
          overflow: hidden;
        }
        .neon-button::before {
          content: '';
          position: absolute;
          top: -2px;
          left: -2px;
          right: -2px;
          bottom: -2px;
          background: linear-gradient(90deg, #ff00ff, #00ffff, #ff00ff);
          background-size: 200% 200%;
          z-index: -1;
          opacity: 0;
          transition: opacity 0.3s ease;
        }
        .neon-button:hover::before {
          opacity: 1;
          animation: neon-border 1.5s linear infinite;
        }
      `}</style>
      <div className="absolute inset-0 flex items-center justify-center">
        <AnimatePresence>
          {!isGameStarted && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <Button 
                onClick={startGame} 
                className="w-56 h-20 text-xl bg-gray-800 text-gray-100 hover:bg-gray-700 rounded-lg shadow-lg neon-button"
              >
                Start Game
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {isGameStarted && countdown > 0 && (
            <motion.div
              key="countdown"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="text-6xl font-bold"
            >
              {countdown}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {isGameStarted && countdown === 0 && (
            <motion.div
              className="text-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.5 }}
            >
              <motion.h2 
                className="text-5xl font-bold mb-6 text-gray-100"
                key={currentWord}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                transition={{ duration: 0.3 }}
              >
                {currentWord}
              </motion.h2>
              <p className="text-xl mb-6 text-gray-300">Score: {score}</p>
              {gameOver && (
                <div>
                  <p className="text-2xl text-red-400 mt-4 mb-4">Game Over!</p>
                  <Button onClick={resetGame} className="text-lg py-2 px-4 bg-gray-800 text-gray-100 hover:bg-gray-700 rounded-md shadow-md">
                    Play Again
                  </Button>
                </div>
              )}
              {!gameOver && (
                <div>
                  <Button 
                    onClick={handleButtonClick} 
                    className="w-56 h-20 text-xl bg-gray-800 text-gray-100 hover:bg-gray-700 rounded-lg shadow-lg"
                  >
                    Bird
                  </Button>
                  <p className="text-lg mt-4 text-gray-400">High Score: {highScore}</p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

