import { BirdGame } from '@/components/BirdGame'

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-start p-8">
      <h1 className="text-4xl font-bold mb-4">Bird Click Game</h1>
      <div className="text-center mb-8">
        <p className="text-xl mb-2">Click the button when you see a bird name!</p>
        <p className="text-xl mb-2">If you see "crow", click within 2 seconds!</p>
        <p className="text-xl">Don't click for non-bird words.</p>
      </div>
      <BirdGame />
    </main>
  )
}

