import { BirdGame } from '@/components/BirdGame'

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-start p-8">
      <h1 className="text-4xl font-bold mb-4">Bird Click Game</h1>
      <p className="text-xl mb-8">Click on 'Bird' button when a bird name comes up</p>
      <BirdGame />
    </main>
  )
}

